from flask import Flask, render_template, request, session
from rating_table import rtable, givescore, giveGV, getloc
import numpy as np
import pandas as pd
import ast
import warnings
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import CountVectorizer
from pandas.core.common import SettingWithCopyWarning
from pandas.core.common import SettingWithCopyWarning
from scipy.sparse import csr_matrix
from sklearn.neighbors import NearestNeighbors
import random
import scipy
import implicit
import mkl
from sklearn.decomposition import TruncatedSVD
from scipy.sparse import csr_matrix
from sklearn.neighbors import NearestNeighbors


merged_data = pd.read_csv('merged_data.csv')

rating_table = rtable()
# Only movies that have been rated before
movie_with_rating = list(rating_table.index)
movies_with_rating = merged_data.loc[merged_data['Title'].isin(movie_with_rating)]

print("RESTARTING")

def giveamovie(genre:str, year:str, index:int) -> set:
    genre = genre
    year = int(year)
   # genre_filter = movies_with_rating[movies_with_rating['Genres'].str.contains('|'.join(genre))]
    genre_filter = movies_with_rating[movies_with_rating['Genres'].str.contains(genre)]
    genre_filter['Year'] = genre_filter['Year'].astype(np.int64)
    year_filter = genre_filter[genre_filter['Year'] > year]
    year_filter = year_filter.reset_index().drop(columns=['index'])
    stage_1 = random.sample(range(0, len(year_filter)), 5)
    stage_1_filter = year_filter.iloc[stage_1].reset_index().drop(columns=['index'])
    extract_title = list(stage_1_filter['Title'])
    return extract_title[0], extract_title[1], extract_title[2], extract_title[3], extract_title[4], extract_title
    

STATIC_FOLDER = 'templates/assets'
app = Flask(__name__,
            static_folder = STATIC_FOLDER)


@app.route('/gvfinal', methods=['POST'])
def gv_final()->'html':
    location = request.form['Location']
    mrt = getloc(location)
    result = session['titles']
    gvmovie1 = result[0][1]
    gvmovie2 = result[1][1]
    gvmovie3 = result[2][1]
    loc1 = mrt[0]
    loc2 = mrt[0]
    if(len(mrt) > 1):
        loc3 = mrt[1]
    else:
        loc3 = mrt[0]
    time1 = '13-4-2021 16:25:00'
    time2 = '13-4-2021 20:25:00'
    time3 = '14-4-2021 10:30:00'
    soon = ['Marvel Studios Black Widow','The Suicide Squad', 'Fast & Furious 9', 'The Conjuring 3: The Devil Made Me Do It', 'A Quiet Place Part II', "Disney's Cruella", 'Top Gun: Maverick', 'Great White','Josee, The Tiger And The Fish', 'Game Changer' , 'The Hypnosis', 'The Unholy']
    if gvmovie1 in soon:
        time1 = 'Coming Soon!'
    if gvmovie2 in soon:
        time2 = 'Coming Soon!'
    if gvmovie3 in soon:
        time3 = 'Coming Soon!'
    
    return render_template('gvfinal.html',
                           gvmovie1 = gvmovie1,
                           gvmovie2 = gvmovie2,
                           gvmovie3 = gvmovie3,
                           loc1 = loc1,
                           loc2 = loc2,
                           loc3 = loc3,
                           time1 = time1,
                           time2 = time2,
                           time3 = time3)



@app.route('/final', methods=['GET','POST'])
def final_page() ->'html':
    score1 = request.form['result1']
    score2 = request.form['result2']
    score3 = request.form['result3']
    score4 = request.form['result4']
    score5 = request.form['result5']
    movie_title = session['titles']
    title = []
    scores = [score1, score2, score3, score4, score5]
    count = 0
    rating_table[672] = 0
    for i in movie_title:
        rating_table[672][rating_table.index == i] = float(scores[count])
        count+=1
    item_user_data = scipy.sparse.csr_matrix(rating_table.values)
    mkl.set_num_threads(2)
    model = implicit.als.AlternatingLeastSquares(factors=360, regularization=0.5)
    model.fit(item_user_data)
    user_items = item_user_data.T.tocsr()
    recommend = model.recommend(671, user_items)[0:5]
    for i in range(4):
        title.append(rating_table.index[recommend[i][0]])
    stage_2_final = merged_data.loc[merged_data['Title'].isin(title)]
    result = giveGV(stage_2_final, rating_table)
    session['titles'] = result
    return render_template('final.html',
                           the_title = 'Movies we recommend',
                           movie1 = rating_table.index[recommend[0][0]],
                           movie2 = rating_table.index[recommend[1][0]],
                           movie3 = rating_table.index[recommend[2][0]],
                           movie4 = rating_table.index[recommend[3][0]],
                           movie5 = rating_table.index[recommend[4][0]])


@app.route('/recommendations', methods=['GET','POST'])
def do_search() -> 'html':
    genre = request.form['Genre']
    year = request.form['Year']
    title = 'Rate the following movies'
    results, results2, results3, results4, results5, titles = giveamovie(genre, year,0)
    session['titles'] = titles
    
    return render_template('results.html',
                           the_genre = genre,
                           the_year = year,
                           the_title = title,
                           the_results = results,
                           the_results2 = results2,
                           the_results3 = results3,
                           the_results4 = results4,
                           the_results5 = results5,)

@app.route('/')
@app.route('/entry')
def entry_page() -> 'html':
    return render_template('entry.html',
                           the_title='Movie Recommender !')

app.secret_key = 'Hi'
if __name__ == '__main__':
    app.run(debug=True, use_reloader=True)
