import numpy as np
import pandas as pd
import ast
import warnings
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import CountVectorizer
from pandas.core.common import SettingWithCopyWarning
from pandas.core.common import SettingWithCopyWarning
from scipy.sparse import csr_matrix
from sklearn.neighbors import NearestNeighbors
import random
import scipy
import implicit
import mkl
import datetime
from sklearn.decomposition import TruncatedSVD
from scipy.sparse import csr_matrix
from sklearn.neighbors import NearestNeighbors

def rtable():
    movies = pd.read_csv('ratings_smallOLD.csv').drop(columns = ['timestamp'])
    link = pd.read_csv('links_small.csv').drop(columns= ['tmdbId'])
    keywords = pd.read_csv('keywords.csv')
    metadata = pd.read_csv('movies_metadata.csv').drop(columns=['vote_count', 'vote_average','video','tagline','status'])
    credit = pd.read_csv('credits.csv')
    merged_data = pd.read_csv('merged_data.csv')
    movie_rating = pd.merge(movies,pd.merge(link,merged_data[['Title','imdbId']], on='imdbId' ),on='movieId')
    movie_ratingCount = movie_rating.groupby(by = ['userId'])['rating'].count().reset_index().rename(columns={"rating":"totalRatingCount"})
    movie_ratingCount = pd.merge(movie_rating, movie_ratingCount, on = 'userId')
    movie_ratingCount = movie_ratingCount.sort_values(by=['userId'])
    movie_ratingCount
    popularity_threshold = 0
    rating_popular = movie_ratingCount.query('totalRatingCount >= @popularity_threshold')
    movie_ratingCount = (rating_popular.groupby(by = ['Title'])['rating'].count().reset_index().rename(columns={"rating":"totalRatingsCount"}))
    movie_ratingCount = pd.merge(rating_popular, movie_ratingCount, on = 'Title')
    movie_ratingCount = movie_ratingCount.sort_values(by=['movieId'])
    popularity_threshold = 0
    rating_popular = movie_ratingCount.query('totalRatingsCount >= @popularity_threshold')
    rating_table = rating_popular.pivot_table(index='Title',columns='userId',values='rating').fillna(0)
    return rating_table


def givescore(title, scores, table):
    count = 0
    table = rtable()
    table[672] = 0
    for i in range(5):
        table[672][table.index == i] = scores[count]
        count+=1
    item_user_data = scipy.sparse.csr_matrix(table.values)
    mkl.set_num_threads(2)
    model = implicit.als.AlternatingLeastSquares(factors=360, regularization=0.5)
    model.fit(item_user_data)
    user_items = item_user_data.T.tocsr()
    recommendations = model.recommend(671, user_items)[0:5]
    return recommendations


def giveGV(stage_2_final, rating_table):
    userfocus = rating_table.transpose()
    R = userfocus.to_numpy()
    user_ratings_mean = np.mean(R, axis = 1)
    svd = TruncatedSVD(n_components=360)
    svd.fit(R)
    all_user_predicted_ratings = svd.inverse_transform(svd.transform(R))
    preds_df = pd.DataFrame(all_user_predicted_ratings, columns = rating_table.index, index=rating_table.columns)
    average = list(preds_df.mean(axis=1))
    for i in range(len(preds_df.index)):
        preds_df.iloc[i] = preds_df.iloc[i] - average[i]
    rating_table = preds_df.transpose()
    # Subtracting Users Mean



    
    stage_2_final = stage_2_final.rename(columns={"Date of Release":"Year"})
    # Importing the Golden Village dataset and handle & fill in nan values
    answer = []
    # The tmdb movies we are using to recommend user the Golden Village movies

    stage_3_initial = stage_2_final[['Title', 'Genres','Available Languages','Year',
                                         'runtime','Cast','Production Company','Overview','Director']]
    stage_3_initial = stage_3_initial.rename(columns = {'Available Languages':'Subtitle',
                                                            'Production Company':'Distributor',
                                                            'Year': 'Date of Release'})


    tmdb_copy = stage_3_initial.copy()


    # Extract user's rating column
    rating_new = rating_table[[672]].reset_index()
    rating_new = rating_new.rename(columns = {672:'Ratings'})

    # Find the movie's user rating and merge it with our tmdb dataset
    tmdb_copy['tmdb_rating'] = 0

    for i in range(len(tmdb_copy)):
        rating = (rating_new.loc[rating_new['Title'] == tmdb_copy['Title'].iloc[i]]).iloc[0]['Ratings']
        tmdb_copy['tmdb_rating'].iloc[i] = rating

    # Import gv dataset
    gv_movie = pd.read_csv("GVMovie_new.csv")
    gv_movie = gv_movie.drop(columns = 'Language')
    gv_movie.head()

    # Preprocess the Overview 
    import nltk
    #nltk.download('stopwords')
    from nltk.corpus import stopwords

    # function to remove punctuation and stopwords from Overview
    def filter_(my_str):
        stop_words = set(stopwords.words('english'))
        punctuations = '''!()-[]{};:'"\,<>./?@#$%^&*_~'''
        no_punct = ""
        
        for char in my_str:
            if char not in punctuations:
                no_punct = no_punct + char
        
        # make no_punct into a list
        string = no_punct.split(' ')
        
        # remove STOPWORDS from string
        filtered = [w for w in string if not w in stop_words]
        
        return filtered

    # Define our own similarity function, and apply it
    def similarity(GV_data, TMDB_data):
        Average = [] # List to store all average of GV movies Vs tmdb movies
        
        for j in range(len(GV_data)): # Iterate through GV movies
            
            weighted_feature = [] # List to store all the features' score before adding them up and calculate average
            
            for i in range(len(TMDB_data)): # Around 3-4
                
                movie_count = [] # List to store that movie's scores with every features
                
                
                
                # 1 - Genre Score Counting
                
                # Step 1 - Make all the Genres in each dataset into two distinct list
                Genre_tmdb = str(TMDB_data['Genres'].iloc[i]).split(", ")
                Genre_tmdb.remove('')
                Genre_GV = str(GV_data['Genres'].iloc[j]).split("/ ")

                # Step 2 - Find the intersected elements, make it into a list
                G_intersect = list(set.intersection(set(Genre_tmdb), set(Genre_GV)))
                
                # We simply found that the len(intersect) will be the number of overlapped elements
                # which basically is the overlapped count we are trying to find
                
                Genre_score = len(G_intersect) * 0.35 # Step 3 - multiply by our weighted importance
                movie_count.append(Genre_score) # Step 4 - Append Genre_score into list
                
                # Next, we will perform the same thing on the rest of the features            
                
                
                
                # 2 - Actor Score Counting
                
                Actor_tmdb = (tmdb_copy['Cast'].iloc[i]).split(", ")
                Actor_tmdb.remove('')
                
                Actor_GV = str(gv_movie['Cast'].iloc[j]).split(", ")
                
                A_intersect = list(set.intersection(set(Actor_tmdb), set(Actor_GV)))
                
                Actor_score = len(A_intersect) * 0.25
                movie_count.append(Actor_score)
                
                
                
                # 3 - Director Score Counting
                
                # Handling tmdb_copy dataset
                Director_tmdb = (tmdb_copy['Director'].iloc[0]).split(", ")
                Director_tmdb.remove('')
                
                Director_GV = (gv_movie['Director'].iloc[0]).split(", ")

                D_intersect = list(set.intersection(set(Director_tmdb), set(Director_GV)))
                
                Director_score = len(D_intersect) * 0.15
                movie_count.append(Director_score)
                
                
                
                # 4 - Overview
                Overview_tmdb = filter_(tmdb_copy['Overview'].iloc[i])
                Overview_GV = filter_(gv_movie['Overview'].iloc[j])

                O_intersect = list(set.intersection(set(Overview_GV), set(Overview_tmdb)))
                
                Overview_score = len(O_intersect) * 0.125
                movie_count.append(Overview_score)
                
                
                
                # 5 - Distributor
                Distributor_tmdb = (tmdb_copy['Distributor'].iloc[0]).split(", ")
                Distributor_tmdb.remove('')
                
                Distributor_GV = (gv_movie['Distributor'].iloc[0]).split(", ")
                
                DD_intersect = list(set.intersection(set(Distributor_tmdb), set(Distributor_GV)))
                
                Distributor_score = len(DD_intersect) * 0.075
                movie_count.append(Distributor_score)
                            
                
                
                # 6 - Subtitle
                
                Subtitle_tmdb = (tmdb_copy['Subtitle'].iloc[0]).split(", ")
                Subtitle_tmdb.remove('')
                
                Subtitle_GV = (gv_movie['Subtitle'].iloc[0]).split(", ")
                
                S_intersect = list(set.intersection(set(Subtitle_tmdb), set(Subtitle_GV)))
                
                Subtitle_score = len(S_intersect) * 0.05
                movie_count.append(Subtitle_score)
                
                
                
                # After we get all the features weighted score, we sum it up
                sim = sum(movie_count)
                
                # Before moving on to next tmdb movie, multiply sim with predicted user rating on the tmdb movie
                weighted = TMDB_data['tmdb_rating'].iloc[i] * sim
                
                # Then, we append it into a new list which store all the 4 movies weighted score
                weighted_feature.append(weighted)
                
                
            # After we get all the sim score of the GV movie against all the 4 tmdb movies,
            # We divide and find the average weighted sim score for that movie
            average_sim = sum(weighted_feature) / len(weighted_feature)
            
            # Append the average weighted sim so that later we can merge it into the gv_movie dataframe
            Average.append(average_sim)
        
        return Average

    # Implement the sim function
    Sim_score = similarity(gv_movie, tmdb_copy)

    # Append the similarity score to a new column
    gv_movie['Similarity'] = Sim_score

    # Here, we can actually print out the top 5 recommended movies by simply sorting the values on 'Similarity'
    # Which is simply to say, can just recommend by the code below

    gv_movie.sort_values(by = 'Similarity', ascending = False).head()

    # But we wanted something more than that

    # Lets print out the above top 5 in a prettier way
    # Sort the similarity score and found the top 5 recommended movies for GV
    top5 = []
    top5.append((gv_movie.sort_values(by = 'Similarity', ascending = False).head()).index)
    top5

    now_showing = []

    # Print these things out
    count = 1
    print("Movies in Golden Village we recommend for you:")
    for i in range(0,5):
        
        # Determine if the movie is out or not
        Y = int(gv_movie.iloc[top5[0][i]]['Date of Release'][:4])
        M = int(gv_movie.iloc[top5[0][i]]['Date of Release'][5:7])
        D = int(gv_movie.iloc[top5[0][i]]['Date of Release'][8:])
        Date = gv_movie.iloc[top5[0][i]]['Date of Release']
        
        today = datetime.date.today()
        someday = datetime.date(Y, M, D)
        diff = someday - today
        
        if(diff.days <= 0):
            print(count,': Now showing in cinema!', gv_movie.iloc[top5[0][i]]['Title'])
            answer.append(['Now showing in cinema!' , gv_movie.iloc[top5[0][i]]['Title']])
        else:
            answer.append(["Coming soon in {}".format(Date), gv_movie.iloc[top5[0][i]]['Title']])
            print(count,':',"Coming soon in", Date, gv_movie.iloc[top5[0][i]]['Title'])
        
        count+=1
    for i in stage_2_final['Title']:
        print(i)
    print("Sum", sum(rating_table[672]))
    print(answer)
    
    return answer


def getloc(location):
    gv_movie = pd.read_csv("GVMovie_new.csv")
    gv_movie = gv_movie.drop(columns = 'Language')
    gv_movie.head()
    sorted_gv = gv_movie

    now_showing = []

    # Print these things out
    count = 1
    print("Movies currently showing in Golden Village we recommend for you:")

    import datetime
    for i in range(15):
        # Determine if the movie is out or not
        Y = int(sorted_gv.iloc[i]['Date of Release'][:4])
        M = int(sorted_gv.iloc[i]['Date of Release'][5:7])
        D = int(sorted_gv.iloc[i]['Date of Release'][8:])
        Date = sorted_gv.iloc[i]['Date of Release']
        
        today = datetime.date.today()
        someday = datetime.date(Y, M, D)
        diff = someday - today
        
        if((diff.days <= 0) & (count<6)):
            print(count, ': ', sorted_gv.iloc[i]['Title'])
            now_showing.append(sorted_gv.iloc[i]['Title'])
            count += 1
        elif(count > 10):
            break
        else:
            continue

            
    mrt_lrt = pd.read_csv("mrtsg.csv")

    mrt = mrt_lrt[~mrt_lrt.STN_NAME.str.contains("LRT")]
    mrt = mrt.reset_index()
    mrt = mrt.drop(columns = ['index','STN_NO','OBJECTID'])
    mrt = mrt.drop_duplicates(subset = ['STN_NAME','COLOR'], keep = 'first')


    # We first ask user to input the region he/she is in
    #print("Which MRT station is the nearest to you now?\n")

    place = location
    place = place.upper()
    #print('Oh I see, you are at somewhere near', place, 'now!\n')


    timing = pd.read_csv("timing.csv")

    # Let's first handle the datetime, we will make DATE(D/M) and TIME into a single column
    timing['Datetime'] = 0
    for i in range(len(timing)):
        value = ""
        value += timing['DATE(D/M)'].loc[i]
        value += ' '
        value += str(timing['TIME'].loc[i])[:-2]
        value += ':'
        value += str(timing['TIME'].loc[i])[-2:]
        value += ':00'
            
        timing['Datetime'].loc[i] = value
        
    timing = timing.drop(columns = ['DATE(D/M)', 'TIME'])

    # To ease the calculation of the nearest GV cinema
    # First, we merge the Longitude and Latitude according to each mrt station into this dataframe
    timing = pd.merge(timing, pd.DataFrame(mrt[['STN_NAME','Latitude','Longitude','COLOR']]), on = 'STN_NAME')

    # Next, we try to merge all the show times of a same movie in a same cinema into a list
    timing = timing.groupby(['Title','STN_NAME','GV', 'Latitude','Longitude','COLOR'])['Datetime'].apply(list).reset_index()

    timing = timing.drop_duplicates(subset = timing.columns[:-1] , keep = 'first')


    # Then, we filter out the recommended movies for the user
    recommended_movie = pd.DataFrame(columns = timing.columns)

    for i in range(len(now_showing)):
        recommended_movie = recommended_movie.append(timing[timing.Title.str.contains(now_showing[i]) == True])
        

    # Let's try and compute the nearest 2 stops from the given place
    # Here, we will use a formula called Harvesine formula to compute the distance between chosen mrt and other mrt

    import math
    R = 6373.0 # Radius of Earth

    # Before we do anything, let's create a 'distance' column to store the computed distance
    recommended_movie['Distance'] = 0

    # First, we extract longitude and latitude of the place where our user is 
    lat1 = math.radians(mrt[mrt['STN_NAME'].str.contains(place)]['Latitude'].iloc[0])
    lon1 = math.radians(mrt[mrt['STN_NAME'].str.contains(place)]['Longitude'].iloc[0])

    # Next, we loop through the whole dataset to compute the distance between given mrt and other mrt
    for i in range(len(recommended_movie)):
        lat2 = math.radians(recommended_movie['Latitude'].iloc[i])
        lon2 = math.radians(recommended_movie['Longitude'].iloc[i])
        
        # Everything's set, let's compute the distance of the two station!
        dlon = lon2 - lon1
        dlat = lat2 - lat1
        
        a = math.sin(dlat / 2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2)**2
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
        distance = R * c
        
        recommended_movie['Distance'].iloc[i] = distance
    

    sorted_reco = recommended_movie.sort_values(by = 'Distance', ascending = True)


    # Let's find out the user's nearest MRT line color, and make it into a list
    color = []
    for i in range(len(mrt[mrt['STN_NAME'].str.contains(place)])):
        color.append(mrt[mrt['STN_NAME'].str.contains(place)]['COLOR'].iloc[i])
        
    
    # Then, we filtered out the GV cinema on the same color line, and sort the distance
    current_line_gv = sorted_reco[sorted_reco['COLOR'] == color[0]]
    for i in range(len(color)-1):
        current_line_gv = current_line_gv.append(sorted_reco[sorted_reco['COLOR'] == color[i+1]])

    # Next, we try to extract the first 2 nearest station which are on the same line
    same_line = []
    #timing.drop_duplicates(subset = timing.columns[:-1] , keep = 'first')
    two_station = current_line_gv[['STN_NAME']].drop_duplicates(keep = 'first').iloc[:2]
    if(len(two_station) < 2): # Only 1 station
        same_line.append(two_station['STN_NAME'].iloc[0])
        
    else:
        for i in range(2):
            same_line.append(two_station['STN_NAME'].iloc[i])

    return same_line
